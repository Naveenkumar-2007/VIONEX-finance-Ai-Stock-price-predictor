"""
VIONEX Finance MLOps Package
Automated model training, versioning, and deployment system
"""

__version__ = "1.0.0"
__author__ = "VIONEX Finance"
